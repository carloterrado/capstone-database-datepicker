</body>

</html><?php /**PATH C:\xampp\htdocs\arkilla\resources\views/partials/__footer.blade.php ENDPATH**/ ?>