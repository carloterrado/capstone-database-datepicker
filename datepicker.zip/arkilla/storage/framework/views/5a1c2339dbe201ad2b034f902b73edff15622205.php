<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>

<body>

    <section class="h-screen flex justify-center items-center">
        <div class="border-2 border-black rounded   p-8 w-login">
            <form action="get">
                <div class="grid gap-4">
                    <h1 class="text-3xl py-4 text-center uppercase">login to your account</h1>
                    <div class="relative input-box">
                        <input type="text" class="border rounded focus:outline-none w-full p-2 peer" required="required" name="email">
                        <label for="email" class="absolute left-0 p-2 pointer-events-none uppercase text-slate-400 duration-500 tracking-widest peer-focus:bg-slate-500 peer-valid:bg-slate-500">Email</label>
                    </div>
                    <div class="relative input-box">
                        <input type="password" class="border rounded focus:outline-none w-full p-2 peer" required="required" name="password">
                        <label for="password" class="absolute left-0 p-2 pointer-events-none uppercase text-slate-400 duration-500 tracking-widest peer-focus:bg-slate-500 peer-valid:bg-slate-500">Password</label>
                    </div>
                    <div class="flex col justify-evenly">
                        <div class="relative pl-8">
                            <input type="radio" name="user" id="renter" class="hidden" checked="checked" value="user">
                            <label for="renter" class="label cursor-pointer tracking-widest">user</label>
                        </div>
                        <div class="relative pl-8">
                            <input type="radio" name="user" id="owner" class="hidden" value="owner">
                            <label for="owner" class="label cursor-pointer tracking-widest">car owner</label>
                        </div>
                    </div>
                    <div class="flex justify-around">
                        <button type="submit" class="relative px-11 border rounded tracking-widest">Login</button>
                        <button class="relative py-1 px-11 border rounded"><a href="#" class="tracking-widest">Register</a></button>
                    </div>
                </div>
            </form>
        </div>
    </section>

</body>

</html><?php /**PATH C:\xampp\htdocs\arkilla\resources\views/login.blade.php ENDPATH**/ ?>