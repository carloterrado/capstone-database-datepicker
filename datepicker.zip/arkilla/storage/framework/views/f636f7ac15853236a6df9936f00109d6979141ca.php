</body>

</html><?php /**PATH C:\xampp\htdocs\arkilla\resources\views/renter/partials/__footer.blade.php ENDPATH**/ ?>